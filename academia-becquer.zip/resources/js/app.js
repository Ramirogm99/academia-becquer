import './bootstrap';
import 'laravel-datatables-vite';
