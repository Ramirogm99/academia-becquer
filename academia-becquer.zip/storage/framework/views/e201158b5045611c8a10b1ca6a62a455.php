<?php $__env->startSection('subtitle', 'Clients'); ?>
<?php $__env->startSection('content_header_title', 'Clientes'); ?>
<?php $__env->startSection('content_header_subtitle', 'Edición de clientes'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-body" style="width: 100% ; height : 100%;">
                <form action="<?php echo e(route('clients.update')); ?>" method="POST">
                    <div class="row">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="client_id" value="<?php echo e($client->id); ?>">
                        <div class="form-group col-3
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="name">Nombre</label>
                            <input type="text" class="form-control" id="name" name="name"
                                value="<?php echo e($client->name); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block
                                text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-3
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="phone">Teléfono</label>
                            <input type="text" class="form-control" id="phone" name="phone"
                                value="<?php echo e($client->phone); ?>">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block
                                text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-3
                        <?php $__errorArgs = ['tutor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="tutor">Tutor</label>
                            <input type="text" class="form-control" id="tutor" name="tutor"
                                value="<?php echo e($client->tutor); ?>">
                            <?php $__errorArgs = ['tutor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block
                                text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-3
                        <?php $__errorArgs = ['school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="school">Colegio</label>
                            <input type="text" class="form-control" id="school" name="school"
                                value="<?php echo e($client->school); ?>">
                            <?php $__errorArgs = ['school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="help-block
                                text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class=" col-3">
                            <label for="level">Nivel Académico</label>
                            <select class="form-control" id="level" name="level" data-live-search="true">
                                <option value="">Selecciona un nivel</option>
                                <option value="1" <?php if($client->level == 1): ?> selected <?php endif; ?>>1º Primaria
                                </option>
                                <option value="2" <?php if($client->level == 2): ?> selected <?php endif; ?>>2º Primaria
                                </option>
                                <option value="3" <?php if($client->level == 3): ?> selected <?php endif; ?>>3º Primaria
                                </option>
                                <option value="4" <?php if($client->level == 4): ?> selected <?php endif; ?>>4º Primaria
                                </option>
                                <option value="5" <?php if($client->level == 5): ?> selected <?php endif; ?>>5º Primaria
                                </option>
                                <option value="6" <?php if($client->level == 6): ?> selected <?php endif; ?>>6º Primaria
                                </option>
                                <option value="7" <?php if($client->level == 7): ?> selected <?php endif; ?>>1º ESO</option>
                                <option value="8" <?php if($client->level == 8): ?> selected <?php endif; ?>>2º ESO</option>
                                <option value="9" <?php if($client->level == 9): ?> selected <?php endif; ?>>3º ESO</option>
                                <option value="10" <?php if($client->level == 10): ?> selected <?php endif; ?>>4º ESO</option>
                                <option value="11" <?php if($client->level == 11): ?> selected <?php endif; ?>>1º Bachillerato
                                </option>
                                <option value="12" <?php if($client->level == 12): ?> selected <?php endif; ?>>2º Bachillerato
                                </option>
                                <option value="13" <?php if($client->level == 13): ?> selected <?php endif; ?>>Universidad
                                </option>
                                <option value="14" <?php if($client->level == 14): ?> selected <?php endif; ?>>Acceso a grados
                                </option>
                                <option value="15" <?php if($client->level == 15): ?> selected <?php endif; ?>>Intensivo
                                    Selectividad</option>
                            </select>
                        </div>
                        <div class=" col-3">
                            <label for="course">Cursos</label>
                            <select class="form-control" id="course" data-live-search="true">
                                <option value="">Selecciona el Curso</option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($course->id); ?>" extra-attr="<?php echo e($course->price); ?>">
                                        <?php echo e($course->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-3 mt-4 p-2">
                            <button type="button" class="btn btn-secondary" id="add-classes">Añadir clase</button>
                        </div>
                    </div>
                    <div id="sortable" class="row mb-5 mt-5">
                        <?php $__currentLoopData = $coursesClient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseClient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 mb-2 item-row">
                                <input type="hidden" name="courses[]" value="<?php echo e($courseClient->id); ?>">
                                <button type="button" class="btn btn-danger remove-class">Eliminar</button>
                                <b>
                                    <?php echo e($courseClient->course->name); ?>

                                </b>
                                <span class="col-2"><?php echo e($courseClient->course->price); ?>€/h</span>
                                <input type="hidden" class="price" value="<?php echo e($courseClient->price); ?>"><input
                                    type="number" class="col-2 ml-2 hours" name="hours[]"
                                    value="<?php echo e($courseClient->hours); ?>">
                                <span class="price_total">Total: <?php echo e($courseClient->total); ?>€</span><input type="hidden"
                                    class="price_calculated" name="price_total[]" value="<?php echo e($courseClient->total); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row ml-2">
                        <div class="mt-5">
                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('#add-classes').click(function() {
                var class_id = $('#course').val();
                if (class_id == '') {
                    alert('Selecciona un curso');
                    return;
                } else {
                    $('#sortable').append(
                        '<div class="col-12 mb-2 item-row"><input type="hidden" name="courses[]" value="' +
                        class_id +
                        '"><button type="button" class="btn btn-danger remove-class">Eliminar</button><b>' +
                        $('#course option:selected').text() +
                        '</b><span class="col-2">' + $(
                            '#course option:selected').attr('extra-attr') +
                        '€/h</span><input type="hidden" class="price" value="' +
                        $(
                            '#course option:selected').attr('extra-attr') +
                        '"><input type="number" class="col-2 ml-2 hours" name="hours[]"><span class="price_total"></span><input type="hidden" class="price_calculated" name="price_total[]" value=""></div>'
                    );
                }
            });
        });
        $(document).on('click', '.remove-class', function() {
            $(this).parent().remove();
        });
        $(document).on('change , keyup', '.hours', function() {
            var hours = $(this).val();
            var price = $(this).closest('.item-row').find('.price').val();
            console.log(hours, price);
            var total = hours * price;
            $(this).closest('.item-row').find('.price_calculated').val(total);
            $(this).parent().find('.price_total').text('Total: ' + total + '€');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-becquer\resources\views/clients/edit.blade.php ENDPATH**/ ?>