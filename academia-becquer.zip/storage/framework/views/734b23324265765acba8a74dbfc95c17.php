<?php $__env->startSection('subtitle', 'Welcome'); ?>
<?php $__env->startSection('content_header_title', 'Inicio'); ?>
<?php $__env->startSection('content_header_subtitle', 'Bienvenido Administrador'); ?>




<?php $__env->startSection('content_body'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <h1 class="text-center">Bienvenido Administrador</h1>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title
                                        ">Clientes</h5>
                                        <p class="card-text">Total de recaudado hoy: <?php echo e($revenueToday); ?> €</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title
                                        ">Clientes</h5>
                                        <p class="card-text">Total de recaudado este mes: <?php echo e($revenueMonth); ?> €</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    
    
<?php $__env->stopPush(); ?>



<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-becquer\resources\views/home.blade.php ENDPATH**/ ?>