<?php $__env->startSection('subtitle', 'Clients'); ?>
<?php $__env->startSection('content_header_title', 'Clientes'); ?>
<?php $__env->startSection('content_header_subtitle', $client->name); ?>



<?php $__env->startSection('content'); ?>
    

    <div class="container">
        <div class="card">
            <div class="card-body" style="width: 100%">
                <div class="col-12 px-0 pb-3 d-lg-flex d-md-flex d-block">
                    <div class="col-3">
                        <p class="mb-0 text-lightest f-14 w-30 text-capitalize font-weight-bold">Nombre</p>
                    </div>
                    <div class="mb-0 text-dark-grey f-14 w-70 text-wrap ql-editor p-0 col-6">
                        <?php echo e($client->name); ?>

                    </div>
                </div>
                <div class="col-12 px-0 pb-3 d-lg-flex d-md-flex d-block">
                    <div class="col-3">
                        <p class="mb-0 text-lightest f-14 w-30 text-capitalize font-weight-bold">Tutor</p>
                    </div>
                    <div class="mb-0 text-dark-grey f-14 w-70 text-wrap ql-editor p-0"><?php echo e($client->tutor); ?></div>
                </div>
                <div class="col-12 px-0 pb-3 d-lg-flex d-md-flex d-block">
                    <div class="col-3">
                        <p class="mb-0 text-lightest f-14 w-30 text-capitalize font-weight-bold">Teléfono</p>
                    </div>
                    <div class="mb-0 text-dark-grey f-14 w-70 text-wrap ql-editor p-0"><?php echo e($client->phone); ?></div>
                </div>
                <div class="col-12 px-0 pb-3 d-lg-flex d-md-flex d-block">
                    <div class="col-3">
                        <p class="mb-0 text-lightest f-14 w-30 text-capitalize font-weight-bold">Nivel Académico</p>
                    </div>
                    <div class="mb-0 text-dark-grey f-14 w-70 text-wrap ql-editor p-0"><?php echo e($level); ?></div>
                </div>
                <div class="col-12 px-0 pb-3 d-lg-flex d-md-flex d-block">
                    <div class="col-3">
                        <p class="mb-0 text-lightest f-14 w-30 text-capitalize font-weight-bold">Colegio</p>
                    </div>
                    <div class="mb-0 text-dark-grey f-14 w-70 text-wrap ql-editor p-0"><?php echo e($client->school); ?></div>
                </div>
                <?php if(isset($courses)): ?>
                    <div class="col-12 px-0 pb-3 d-lg-flex d-md-flex d-block">
                        <div class="col-3">
                            <p class="mb-0 text-lightest f-14 w-30 text-capitalize font-weight-bold">Cursos a los que
                                asiste:</p>
                        </div>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-0 text-dark-grey f-14 w-70 text-wrap ql-editor p-0 ml-1"><?php echo e($course->course->name); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-becquer\resources\views/clients/show.blade.php ENDPATH**/ ?>